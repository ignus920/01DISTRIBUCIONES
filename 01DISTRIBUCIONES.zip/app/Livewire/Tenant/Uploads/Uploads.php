<?php

namespace App\Livewire\Tenant\Uploads;

use App\Models\TAT\Categories\TatCategories;
use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
//Modelos
use App\Models\TAT\Routes;
use App\Models\TAT\Routes\TatRoutes;
use App\Models\Tenant\Remissions\InvRemissions;
use App\Models\Tenant\DeliveriesList\DisDeliveriesList;
use App\Models\Tenant\DeliveriesList\DisDeliveries;
//Services
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Barryvdh\DomPDF\Facade\Pdf;

class Uploads extends Component
{
    //Propiedades para la tabla
    public $showModal = false;
    public $search = '';
    public $sortField = 'consecutive';
    public $sortDirection = 'desc';
    public $perPage = 10;


    public $selectedDate = '';
    public $remissions = [];
    public $selectedDeliveryMan = '';
    public $showScares = false;
    public $scarceUnits = [];
    public $showformMovements = false;
    public $showConfirmModal = false;
    public $showFooter = true;
    public $showClearOptions = false;


    // impresion de carges 
    public $showCharge = "pedidos";


    public function updatedSelectedDate($value)
    {
        // Solo hacer la consulta si hay fecha válida
        if ($value) {
            try {
                $this->remissions = $this->getRemissions($value);
            } catch (\Exception $e) {
                session()->flash('error', 'Error al cargar las remisiones: ' . $e->getMessage());
                $this->remissions = [];
            }
        } else {
            $this->remissions = [];
        }
    }

    public function updatedSelectedDeliveryMan($value)
    {
        if ($value && $this->selectedDeliveryMan) {
            $this->remissions = $this->getRemissions($this->selectedDate);
        }
    }

    public function getRemissions($date)
    {
        // Usamos una subconsulta para calcular el campo "existe"
        $subquery = DB::table('vnt_quotes as q')
            ->select(
                'q.id',
                'q.userId',
                'q.created_at',
                'q.customerId',
                DB::raw("CASE WHEN EXISTS (
                    SELECT 1 
                    FROM dis_deliveries_list d 
                    WHERE d.salesman_id = q.userId
                    AND d.sale_date = DATE(q.created_at)
                ) THEN 'SI' ELSE 'NO' END as existe")
            );

        // if ($routeId) {
        //     $subquery->where('r.routeId', $routeId);
        // }

        // Consulta principal
        $query = DB::table(DB::raw("({$subquery->toSql()}) as q"))
            ->mergeBindings($subquery)
            ->join('users as u', 'q.userId', '=', 'u.id')
            ->join('inv_remissions as r', 'q.id', '=', 'r.quoteId')
            ->join('tat_companies_routes as cXr', 'q.customerId', '=', 'cXr.company_id')
            ->join('tat_routes as rt', 'cXr.route_id', '=', 'rt.id')
            ->select(
                'u.name',
                'q.userId',
                'rt.name as ruta',
                DB::raw('DATE(q.created_at) as fecha'),
                DB::raw('COUNT(*) as total_registros'),
                DB::raw('MAX(q.existe) as existe')
            )
            ->whereDate('q.created_at', $date)
            ->where('r.status', 'REGISTRADO');

        // Agregar esto para depurar
        // Log::info('Consulta SQL:', [
        //     'sql' => $query->toSql(),
        //     'bindings' => $query->getBindings(),
        //     'date' => $date,
        //     'routeId' => $routeId
        // ]);

        return $query->groupBy('u.id', 'u.name', DB::raw('DATE(q.created_at)'), 'rt.name')->get();
    }

    public function sortBy($field)
    {
        if ($this->sortField === $field) {
            $this->sortDirection = $this->sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortDirection = 'asc';
        }

        $this->sortField = $field;
        $this->resetPage();
    }

    public function clearDate()
    {
        $this->selectedDate = '';
        $this->remissions = [];
    }

    public function cargar($userId)
    {
        if (!$this->selectedDate) {
            session()->flash('error', 'Por favor selecciona una fecha primero');
            return;
        }

        if (!$this->selectedDeliveryMan) {
            session()->flash('error', 'Por favor selecciona un transportador primero');
            return;
        }

        try {
            $uploadData = [
                'sale_date' => $this->selectedDate,
                'salesman_id' => $userId,
                'deliveryman_id' => $this->selectedDeliveryMan,
                'user_id' => Auth::id(),
                'created_at' => Carbon::now()
            ];
            DisDeliveriesList::create($uploadData);

            $this->remissions = $this->getRemissions($this->selectedDate);

            session()->flash('message', "Cargando datos para el usuario ID: $userId - Fecha: {$this->selectedDate}");
        } catch (\Exception $e) {
            Log::error($e);
            session()->flash('error', "Error al registrar el cargue" . $e->getMessage());
        }
    }

    public function eliminar($userId)
    {
        if (!$this->selectedDate) {
            session()->flash('error', 'Por favor selecciona una fecha primero');
            return;
        }

        try {
            // Buscar y eliminar el registro
            $deleted = DisDeliveriesList::where('salesman_id', $userId)
                ->whereDate('sale_date', $this->selectedDate)
                ->delete();

            if ($deleted) {
                // Recargar los datos de la tabla
                $this->remissions = $this->getRemissions($this->selectedDate);

                session()->flash('message', "Registro eliminado exitosamente");
            } else {
                session()->flash('warning', "No se encontró el registro para eliminar");
            }
        } catch (\Exception $e) {
            Log::error($e);
            session()->flash('error', "Error al eliminar el registro: " . $e->getMessage());
        }
    }

    public function validateScarce()
    {
        $result = DB::selectOne("
        SELECT 
            CASE 
                WHEN EXISTS (
                    SELECT 1 
                    FROM dis_deliveries_list dl 
                    INNER JOIN vnt_quotes q ON dl.salesman_id = q.userId 
                        AND DATE(q.created_at) = dl.sale_date 
                    INNER JOIN vnt_detail_quotes dt ON dt.quoteId = q.id 
                    LEFT JOIN inv_items_store its ON dt.itemId = its.itemId 
                    GROUP BY dt.itemId, its.stock_items_store 
                    HAVING SUM(dt.quantity) > COALESCE(its.stock_items_store, 0)
                       OR its.stock_items_store IS NULL
                    LIMIT 1
                ) THEN 'SI' 
                ELSE 'NO' 
            END AS hay_faltantes");

        return $result->hay_faltantes;
    }

    public function showConfirmUploadModal()
    {
        $this->showConfirmModal = true;
    }

    public function cancelConfirmUpload()
    {
        $this->showConfirmModal = false;
        $this->showFooter = true;
        $this->showClearOptions = false;
    }


    public function confirmUpload()
    {
        $this->showConfirmModal = false;

        $hayFaltantes = $this->validateScarce();

        if ($hayFaltantes === 'SI') {
            $this->showScares = true;
            $this->scarceUnits = $this->getscarceUnits();
            return;
        } else {
            try {
                $infoDisDeliveriesList = DisDeliveriesList::where('user_id', Auth::id())->get();
                foreach ($infoDisDeliveriesList as $deliveryListItem) {
                    $dataDeliveries = [
                        'salesman_id' => $deliveryListItem->salesman_id,
                        'deliveryman_id' => $deliveryListItem->deliveryman_id,
                        'user_id' => Auth::id(),
                        'sale_date' => $deliveryListItem->sale_date,
                        'created_at' => Carbon::now()
                    ];

                    //Registro en la tabla dis_deliveries
                    $dis_deliveries = DisDeliveries::create($dataDeliveries);


                    //Actualización registros en la tabla inv_remissions
                    InvRemissions::where('userId', $deliveryListItem->salesman_id)
                        ->whereDate('created_at', $deliveryListItem->sale_date)
                        ->where('status', 'REGISTRADO')
                        ->update(['delivery_id' => $dis_deliveries->id, 'deliveryDate' => $dis_deliveries->sale_date, 'status' => 'EN RECORRIDO']);
                }

                $this->clearListUpload();
                // Si no hay faltantes, proceder con la lógica de confirmación
                session()->flash('message', 'Cargue confirmado exitosamente.');
            } catch (\Exception $e) {
                Log::error($e);
                session()->flash('error', "Error al registrar el cargue: " . $e->getMessage());
            }
        }
    }

    public function getscarceUnits()
    {
        $results = DB::table('dis_deliveries_list as dl')
            ->join('vnt_quotes as q', function ($join) {
                $join->on('dl.salesman_id', '=', 'q.userId')
                    ->on(DB::raw('DATE(q.created_at)'), '=', 'dl.sale_date');
            })
            ->join('vnt_detail_quotes as dt', 'dt.quoteId', '=', 'q.id')
            ->join('inv_items as i', 'i.id', '=', 'dt.itemId')
            ->join('inv_categories as c', 'i.categoryId', '=', 'c.id')
            ->leftJoin('inv_items_store as its', 'i.id', '=', 'its.itemId')
            ->select(
                'i.name as nombre_item',
                'c.name as categoria',
                DB::raw('SUM(dt.quantity) as cantidad_pedida'),
                DB::raw('COALESCE(its.stock_items_store, 0) as stock_actual'),
                DB::raw('COALESCE(its.stock_items_store, 0) - SUM(dt.quantity) as diferencia'),
                DB::raw("CASE
                    WHEN its.stock_items_store IS NULL THEN 'SI - No existe en inventario'
                    WHEN SUM(dt.quantity) > its.stock_items_store THEN 'SI'
                    ELSE 'NO'
                    END as tiene_faltante")
            )
            ->groupBy('i.id', 'i.name', 'c.name', 'its.stock_items_store')
            ->havingRaw('its.stock_items_store IS NULL OR SUM(dt.quantity) > its.stock_items_store')
            ->get();
        return $results;
    }

    public function closeAlertScares()
    {
        $this->showScares = false;
    }

    public function openMovementForm()
    {
        //$this->dispatch("openMovementForm");
        //$this->showModal = true;
        //$this->showScares = false;

    }

    public function closeModal()
    {
        $this->showConfirmModal = false;
        $this->showFooter = true;
        $this->showClearOptions = false;
    }

    public function clearListUpload()
    {
        try {
            $deleted = DisDeliveriesList::where('user_id', Auth::id())
                ->delete();
            if ($deleted) {
                session()->flash('message', "La lista de cargue se vació exitosamente");
            } else {
                session()->flash('error', "No se encontraron registros para eliminar");
            }
            $this->showConfirmModal = false;
            $this->showFooter = true;
            $this->showClearOptions = false;
        } catch (\Exception $e) {
            Log::error($e);
            session()->flash('error', "Error al eliminar los registros: " . $e->getMessage());
        }
    }

    public function printPreCharge()
    {
        if (!$this->selectedDeliveryMan) {
            session()->flash('error', 'Por favor selecciona un transportador primero');
            return;
        }

        try {
            // Obtener items con la consulta SQL ordenados por categoría
            $items = DB::table('dis_deliveries_list as dl')
                ->join('inv_remissions as r', function ($join) {
                    $join->on('dl.salesman_id', '=', 'r.userId')
                        ->whereRaw('DATE(r.created_at) = dl.sale_date');
                })
                ->join('inv_detail_remissions as dt', 'dt.remissionId', '=', 'r.id')
                ->join('inv_items as i', 'i.id', '=', 'dt.itemId')
                ->leftJoin('inv_items_store as its', 'i.id', '=', 'its.itemId')
                ->join('inv_categories as c', 'i.categoryId', '=', 'c.id')
                ->where('dl.deliveryman_id', $this->selectedDeliveryMan)
                ->select(
                    'i.internal_code as code',
                    'c.name as category',
                    'i.name as name_item',
                    DB::raw('SUM(dt.quantity) as quantity'),
                    'its.stock_items_store as stockActual',
                    DB::raw('SUM(dt.quantity) * dt.value as subtotal')
                )
                ->groupBy('c.id', 'c.name', 'i.id', 'i.name', 'dt.value', 'its.stock_items_store', 'i.internal_code')
                ->orderBy('c.name')
                ->orderBy('i.name')
                ->get();

            // Calcular el total
            $total = collect($items)->sum('subtotal');

            $cleanedItems = $this->cleanUtf8Data($items);
            $cleanedTotal = $this->cleanString((string)$total);

            $data = [
                'items' => $cleanedItems,
                'total' => $cleanedTotal,
            ];

            $pdf = PDF::loadView('tenant.uploads.pre-charge-pdf', $data);
            return response()->streamDownload(function () use ($pdf) {
                echo $pdf->stream();
            }, 'pre-cargue.pdf');
        } catch (\Exception $e) {
            Log::error($e);
            session()->flash('error', "Error al generar la impresión: " . $e->getMessage());
        }
    }

    public function render()
    {
        $users = DB::table('users')->select('id', 'name')->where('profile_id', 13)->get();
        return view('livewire.tenant.uploads.uploads', [
            'users' => $users,
            'remissions' => $this->remissions,
            'scarceUnits' => $this->scarceUnits,
        ]);
    }

    private function cleanUtf8Data($data)
    {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = $this->cleanUtf8Data($value);
            }
            return $data;
        } elseif (is_object($data)) {
            // Si es un objeto, convertirlo a array, verificando si tiene el método toArray
            $dataArray = method_exists($data, 'toArray') ? $data->toArray() : (array) $data;
            return $this->cleanUtf8Data($dataArray);
        } elseif (is_string($data)) {
            // Limpiar la cadena UTF-8
            $cleaned = mb_convert_encoding($data, 'UTF-8', 'UTF-8');
            // Remover caracteres inválidos
            $cleaned = preg_replace('/[^\x{0000}-\x{007F}]/u', '', $cleaned);
            // Otra alternativa más agresiva
            $cleaned = iconv('UTF-8', 'UTF-8//IGNORE//TRANSLIT', $data);
            return $cleaned;
        }
        return $data;
    }

    private function cleanString($string)
    {
        // Primero intentar con iconv
        $string = iconv('UTF-8', 'UTF-8//IGNORE', $string);

        // Si aún hay problemas, usar regex para eliminar caracteres no UTF-8 válidos
        $string = preg_replace('/[^\x{0000}-\x{007F}\x{00A0}-\x{00FF}]/u', '', $string);

        // Convertir entidades HTML si es necesario
        $string = html_entity_decode($string, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        return $string;
    }
}

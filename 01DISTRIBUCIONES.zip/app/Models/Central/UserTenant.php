<?php

namespace App\Models\Models\Central;

use Illuminate\Database\Eloquent\Model;

class UserTenant extends Model
{
    //
}

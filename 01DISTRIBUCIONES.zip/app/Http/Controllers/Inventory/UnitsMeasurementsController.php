<?php

namespace App\Http\Controllers\Inventory;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UnitsMeasurementsController extends Controller
{
    public function homeUnits() {
        return view('inventory.unitMeasurement');
    }
}

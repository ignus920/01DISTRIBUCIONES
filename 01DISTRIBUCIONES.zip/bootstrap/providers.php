<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RouteInventoryServiceProvider::class,
    App\Providers\VoltServiceProvider::class,
    App\Providers\ConfigurationServiceProvider::class,
];

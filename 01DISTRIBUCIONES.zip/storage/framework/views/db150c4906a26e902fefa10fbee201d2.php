<div>

    <!--[if BLOCK]><![endif]--><?php if(!$reusable): ?>
    <div class="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
        <div class="max-w-12xl mx-auto">
            <!-- Header -->
            <div
                class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-6">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
                            Gestión de Movimientos
                            <span class="text-xl font-semibold text-gray-700 dark:text-gray-300">
                                | <?php echo e($this->warehouseMovement); ?>

                            </span>
                        </h1>
                        <p class="text-gray-600 dark:text-gray-400 mt-1">Administración de movimientos del sistema</p>
                    </div>
                    <div
                        class="flex flex-col sm:flex-row items-start sm:items-start justify-start sm:justify-between gap-4">
                        <button wire:click="create"
                            class="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 border border-transparent rounded-lg font-semibold text-xs text-white uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition ease-in-out duration-150">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 4v16m8-8H4"></path>
                            </svg>
                            Agregar
                        </button>
                        <div
                            class="flex flex-col sm:flex-row items-start sm:items-start justify-start sm:justify-between gap-4">
                            <button wire:click="$set('movementType', 'entrada')"
                                class="inline-flex items-center px-4 py-2 rounded-lg font-semibold text-xs uppercase transition-all duration-200 <?php echo e($movementType === 'entrada' ? 'bg-green-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'); ?>">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 4v16m0 0l-4-4m4 4l4-4"></path>
                                </svg>
                                Entradas
                            </button>
                            <button wire:click="$set('movementType', 'salida')"
                                class="inline-flex items-center px-4 py-2 rounded-lg font-semibold text-xs uppercase transition-all duration-200 <?php echo e($movementType === 'salida' ? 'bg-red-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'); ?>">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 20V4m0 0l4 4m-4-4l-4 4"></path>
                                </svg>
                                Salidas
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Movement List Component -->
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    <?php echo e($movementType === 'entrada' ? 'Movimientos de Entrada' : 'Movimientos de Salida'); ?>

                </h2>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tenant.movements.components.movement-list', ['type' => $movementType]);

$__html = app('livewire')->mount($__name, $__params, $movementType, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>

        <!-- Modal -->
        <!--[if BLOCK]><![endif]--><?php if($showModal): ?>
        <div
            class="fixed inset-0 bg-gray-600 dark:bg-gray-900 bg-opacity-50 dark:bg-opacity-75 overflow-y-auto h-full w-full z-50">
            <div class="relative min-h-screen flex items-center justify-center p-4">
                <div class="relative bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full">
                    <!-- Header -->
                    <div
                        class="border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            Nuevo Movimiento
                            <span class="text-base font-medium text-gray-700 dark:text-gray-300">
                                | <?php echo e($this->warehouseMovement); ?>

                            </span>
                        </h3>
                        <button wire:click="closeModal"
                            class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Content -->
                    <div class="p-6">
                        <!-- Messages -->
                        <!--[if BLOCK]><![endif]--><?php if($successMessage): ?>
                        <div
                            class="mb-4 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                            <p class="text-sm text-green-700 dark:text-green-400"><?php echo e($successMessage); ?></p>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php if($errorMessage): ?>
                        <div
                            class="mb-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                            <p class="text-sm text-red-700 dark:text-red-400"><?php echo e($errorMessage); ?></p>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!-- Form -->
                        <div class="space-y-4">
                            <!-- Tipo de Movimiento -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <!-- Bodegas -->
                                <!--[if BLOCK]><![endif]--><?php if($showSelectStore): ?>
                                <div>
                                    <label
                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Bodega
                                        <span class="text-red-500">*</span></label>
                                    <select wire:model.live="selectedStoreId" <?php echo e(!empty($selectedStoreId) ? 'disabled'
                                        : ''); ?>

                                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 <?php echo e(!empty($selectedStoreId) ? 'opacity-75 cursor-not-allowed' : ''); ?>">
                                        <option value="">Seleccionar</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($store->id); ?>"><?php echo e($store->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedStoreId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                        Tipo de Movimiento <span class="text-red-500">*</span>
                                    </label>
                                    <div class="flex gap-4 justify-center">
                                        <label
                                            class="flex items-center <?php echo e(!empty($warehouseForm['movementType']) ? 'cursor-not-allowed' : 'cursor-pointer'); ?>">
                                            <input type="radio" wire:model.live="warehouseForm.movementType"
                                                value="ENTRADA" class="sr-only peer" <?php echo e(!empty($warehouseForm['movementType']) ? 'disabled' : ''); ?>>
                                            <div
                                                class="flex items-center px-4 py-2 border-2 rounded-lg transition-all border-gray-300 dark:border-gray-600 peer-checked:border-green-500 peer-checked:bg-green-50 dark:peer-checked:bg-green-900/20 <?php echo e(!empty($warehouseForm['movementType']) ? 'opacity-75' : ''); ?>">
                                                <svg class="w-5 h-5 mr-2 text-green-600 dark:text-green-400" fill="none"
                                                    stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                                </svg>
                                                <span
                                                    class="text-sm font-medium text-gray-700 dark:text-gray-300">Entradas</span>
                                            </div>
                                        </label>
                                        <label
                                            class="flex items-center <?php echo e(!empty($warehouseForm['movementType']) ? 'cursor-not-allowed' : 'cursor-pointer'); ?>">
                                            <input type="radio" wire:model.live="warehouseForm.movementType"
                                                value="SALIDA" class="sr-only peer" <?php echo e(!empty($warehouseForm['movementType']) ? 'disabled' : ''); ?>>
                                            <div
                                                class="flex items-center px-4 py-2 border-2 rounded-lg transition-all border-gray-300 dark:border-gray-600 peer-checked:border-red-500 peer-checked:bg-red-50 dark:peer-checked:bg-red-900/20 <?php echo e(!empty($warehouseForm['movementType']) ? 'opacity-75' : ''); ?>">
                                                <span
                                                    class="text-sm font-medium text-gray-700 dark:text-gray-300">Salidas</span>
                                                <svg class="w-5 h-5 ml-2 text-red-600 dark:text-red-400" fill="none"
                                                    stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                                                </svg>
                                            </div>
                                        </label>
                                    </div>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['warehouseForm.movementType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <!-- Motivo -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                        Motivo <span class="text-red-500">*</span>
                                    </label>
                                    <select wire:model.live="movementForm.reasonId" <?php if(( empty($selectedStoreId) &&
                                        $showSelectStore ) || empty($warehouseForm['movementType']) ||
                                        !empty($movementForm['reasonId'])): ?> disabled <?php endif; ?>
                                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                        <option value=""><?php echo e(empty($warehouseForm['movementType']) ? 'Primero seleccione
                                            el tipo' : 'Seleccionar motivo'); ?></option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($reason->id); ?>"><?php echo e($reason->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['movementForm.reasonId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                            <!-- Observaciones -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Observaciones
                                </label>
                                <textarea wire:model.defer="movementForm.observations" rows="3"
                                    class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400"></textarea>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['movementForm.observations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <!-- Items Section (only if reason is selected) -->
                            <!--[if BLOCK]><![endif]--><?php if(!empty($movementForm['reasonId'])): ?>
                            <div class="border-t border-gray-200 dark:border-gray-700 pt-4">
                                <h4 class="font-medium text-gray-900 dark:text-white mb-4">Agregar productos</h4>

                                <div class="grid grid-cols-3 gap-4 mb-4">
                                    <div>
                                        <label
                                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Item
                                            *</label>
                                        <select wire:model.defer="detailForm.itemId"
                                            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                            <option value="">Seleccionar</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['detailForm.itemId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label
                                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Cantidad
                                            *</label>
                                        <input type="number" step="0.01" wire:model.defer="detailForm.quantity"
                                            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['detailForm.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label
                                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Unidad
                                            *</label>
                                        <select wire:model.defer="detailForm.unitMeasurementId"
                                            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                            <option value="">Seleccionar</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->unitMeasurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->description); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['detailForm.unitMeasurementId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span
                                            class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>

                                <button wire:click="addDetail" type="button"
                                    class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white rounded-lg transition-colors">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M12 4v16m8-8H4"></path>
                                    </svg>
                                    Agregar Item
                                </button>
                            </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!-- Details Table -->
                            <!--[if BLOCK]><![endif]--><?php if(count($details) > 0): ?>
                            <div class="mt-4 overflow-x-auto">
                                <table class="w-full border border-gray-200 dark:border-gray-700 rounded-lg">
                                    <thead class="bg-gray-50 dark:bg-gray-900">
                                        <tr>
                                            <th
                                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Item</th>
                                            <th
                                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Sku</th>
                                            <th
                                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Cant Movimiento</th>
                                            <th
                                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Unidad medida</th>
                                            <th
                                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Unidad consumo</th>
                                            <th
                                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Cant Actual</th>
                                            <th
                                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Cant Ajustada</th>
                                            <th
                                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Precio base</th>
                                            <th
                                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Precio final</th>
                                            <th
                                                class="px-4 py-2 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                                Acción</th>
                                        </tr>
                                    </thead>
                                    <tbody
                                        class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                            <td class="px-4 py-2 text-sm text-gray-900 dark:text-white"><?php echo e($detail['itemName']); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($detail['sku']); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-900 dark:text-white"><?php echo e(number_format($detail['quantity'], 0)); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($detail['unitMeasurementName']); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($detail['consumptionUnitName']); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e(number_format($detail['currentQuantity'], 0)); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e(number_format($detail['adjustedQuantity'], 0)); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400">$<?php echo e(number_format($detail['price'], 0)); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-900 dark:text-white font-semibold">
                                                $<?php echo e(number_format($detail['total'], 0)); ?></td>
                                            <td class="px-4 py-2 text-center">
                                                <button wire:click="removeDetail(<?php echo e($index); ?>)"
                                                    class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300 transition-colors">
                                                    <svg class="w-5 h-5 inline" fill="none" stroke="currentColor"
                                                        viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            stroke-width="2"
                                                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                                        </path>
                                                    </svg>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Actions -->
                        <div class="mt-6 flex justify-end gap-2">
                            <button wire:click="closeModal" type="button"
                                class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                Cancelar
                            </button>
                            <button wire:click="saveMovement" type="button"
                                class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white rounded-lg transition-colors">
                                Guardar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Modal de Detalles del Movimiento -->
        <!--[if BLOCK]><![endif]--><?php if($showDetailsModal && !empty($movementDetails)): ?>
        <div class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                <!-- Header -->
                <div
                    class="sticky top-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        Detalles del Movimiento #<?php echo e($movementDetails['consecutive']); ?>

                    </h3>
                    <button wire:click="closeDetailsModal"
                        class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>

                <!-- Información del Movimiento -->
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400">Fecha</p>
                            <p class="text-sm font-medium text-gray-900 dark:text-white">
                                <?php echo e($movementDetails['date']); ?>

                            </p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400">Tipo</p>
                            <p class="text-sm font-medium text-gray-900 dark:text-white">
                                <?php echo e($movementDetails['type']); ?>

                            </p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400">Bodega</p>
                            <p class="text-sm font-medium text-gray-900 dark:text-white">
                                <?php echo e($movementDetails['store_name']); ?>

                            </p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400">Usuario</p>
                            <p class="text-sm font-medium text-gray-900 dark:text-white">
                                <?php echo e($movementDetails['user_name']); ?>

                            </p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400">Razón</p>
                            <p class="text-sm font-medium text-gray-900 dark:text-white">
                                <?php echo e($movementDetails['reason_name']); ?>

                            </p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400">Estado</p>
                            <!--[if BLOCK]><![endif]--><?php if($movementDetails['status'] === 1): ?>
                            <span
                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                                Registrado
                            </span>
                            <?php else: ?>
                            <span
                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                                Anulado
                            </span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div class="mt-4">
                        <p class="text-sm text-gray-500 dark:text-gray-400">Observaciones</p>
                        <p class="text-sm font-medium text-gray-900 dark:text-white">
                            <?php echo e($movementDetails['observations'] ? $movementDetails['observations'] : 'Sin observaciones'); ?>

                        </p>
                    </div>
                </div>

                <!-- Tabla de Items -->
                <div class="px-6 py-4">
                    <h4 class="text-sm font-semibold text-gray-900 dark:text-white mb-3">Items del Movimiento</h4>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                            <thead class="bg-gray-50 dark:bg-gray-700">
                                <tr>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                                        Producto</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                                        Cantidad</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                                        Unidad</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $movementDetails['details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                    <td class="px-4 py-2 text-sm text-gray-900 dark:text-white">
                                        <?php echo e($detail['item_name']); ?>

                                    </td>
                                    <td class="px-4 py-2 text-sm text-gray-900 dark:text-white">
                                        <?php echo e($detail['quantity']); ?>

                                    </td>
                                    <td class="px-4 py-2 text-sm text-gray-900 dark:text-white">
                                        <?php echo e($detail['unit_name']); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3"
                                        class="px-4 py-4 text-center text-sm text-gray-500 dark:text-gray-400">
                                        No hay items en este movimiento
                                    </td>
                                </tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>

            <!-- Footer -->
            <div class="bg-gray-50 dark:bg-gray-700 px-6 py-4 flex justify-between items-center">
                <div>
                    <!--[if BLOCK]><![endif]--><?php if($movementDetails['status'] === 1): ?>
                        <button @click="$dispatch('confirm-annul-from-details', { movementId: <?php echo e($movementDetails['id']); ?>, consecutive: '<?php echo e($movementDetails['consecutive']); ?>' })"
                            class="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600 text-white rounded-lg transition-colors text-sm font-medium focus:outline-none focus:ring-2 focus:ring-red-500">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                            Anular Movimiento
                        </button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <button wire:click="closeDetailsModal"
                    class="px-4 py-2 bg-gray-200 dark:bg-gray-600 text-gray-900 dark:text-white rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors text-sm font-medium">
                    Cerrar
                </button>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <?php else: ?>

    

    <!-- Modal para registrar nuevo movimiento -->
    <!--[if BLOCK]><![endif]--><?php if($showModal): ?>
    <div
        class="fixed inset-0 bg-gray-600 dark:bg-gray-900 bg-opacity-50 dark:bg-opacity-75 overflow-y-auto h-full w-full z-50">
        <div class="relative min-h-screen flex items-center justify-center p-4">
            <div class="relative bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full">
                <!-- Header -->
                <div class="border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex justify-between items-center">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        Nuevo Movimiento
                        <span class="text-base font-medium text-gray-700 dark:text-gray-300">
                            | <?php echo e($this->warehouseMovement); ?>

                        </span>
                    </h3>
                    <button wire:click="closeModal"
                        class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>

                <!-- Content --> 
                <div class="p-6">
                    <!-- Messages -->
                    <!--[if BLOCK]><![endif]--><?php if($successMessage): ?>
                    <div
                        class="mb-4 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                        <p class="text-sm text-green-700 dark:text-green-400"><?php echo e($successMessage); ?></p>
                    </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]--><?php if($errorMessage): ?>
                    <div
                        class="mb-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                        <p class="text-sm text-red-700 dark:text-red-400"><?php echo e($errorMessage); ?></p>
                    </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Form -->
                    <div class="space-y-4">
                        <!-- Tipo de Movimiento -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <!-- Bodegas -->
                            <!--[if BLOCK]><![endif]--><?php if($showSelectStore): ?>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Bodega
                                    <span class="text-red-500">*</span></label>
                                <select wire:model.live="selectedStoreId" <?php echo e(!empty($selectedStoreId) ? 'disabled' : ''); ?>

                                    class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 <?php echo e(!empty($selectedStoreId) ? 'opacity-75 cursor-not-allowed' : ''); ?>">
                                    <option value="">Seleccionar</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($store->id); ?>"><?php echo e($store->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedStoreId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Tipo de Movimiento <span class="text-red-500">*</span>
                                </label>
                                <div class="flex gap-4 justify-center">
                                    <label
                                        class="flex items-center <?php echo e(!empty($warehouseForm['movementType']) ? 'cursor-not-allowed' : 'cursor-pointer'); ?>">
                                        <input type="radio" wire:model.live="warehouseForm.movementType" value="ENTRADA"
                                            class="sr-only peer" <?php echo e(!empty($warehouseForm['movementType']) ? 'disabled'
                                            : ''); ?>>
                                        <div
                                            class="flex items-center px-4 py-2 border-2 rounded-lg transition-all border-gray-300 dark:border-gray-600 peer-checked:border-green-500 peer-checked:bg-green-50 dark:peer-checked:bg-green-900/20 <?php echo e(!empty($warehouseForm['movementType']) ? 'opacity-75' : ''); ?>">
                                            <svg class="w-5 h-5 mr-2 text-green-600 dark:text-green-400" fill="none"
                                                stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                            </svg>
                                            <span
                                                class="text-sm font-medium text-gray-700 dark:text-gray-300">Entradas</span>
                                        </div>
                                    </label>
                                    <label
                                        class="flex items-center <?php echo e(!empty($warehouseForm['movementType']) ? 'cursor-not-allowed' : 'cursor-pointer'); ?>">
                                        <input type="radio" wire:model.live="warehouseForm.movementType" value="SALIDA"
                                            class="sr-only peer" <?php echo e(!empty($warehouseForm['movementType']) ? 'disabled'
                                            : ''); ?>>
                                        <div
                                            class="flex items-center px-4 py-2 border-2 rounded-lg transition-all border-gray-300 dark:border-gray-600 peer-checked:border-red-500 peer-checked:bg-red-50 dark:peer-checked:bg-red-900/20 <?php echo e(!empty($warehouseForm['movementType']) ? 'opacity-75' : ''); ?>">
                                            <span
                                                class="text-sm font-medium text-gray-700 dark:text-gray-300">Salidas</span>
                                            <svg class="w-5 h-5 ml-2 text-red-600 dark:text-red-400" fill="none"
                                                stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                                            </svg>
                                        </div>
                                    </label>
                                </div>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['warehouseForm.movementType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!-- Motivo -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Motivo <span class="text-red-500">*</span>
                                </label>
                                <select wire:model.live="movementForm.reasonId" <?php if(( empty($selectedStoreId) &&
                                    $showSelectStore ) || empty($warehouseForm['movementType']) ||
                                    !empty($movementForm['reasonId'])): ?> disabled <?php endif; ?>
                                    class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                    <option value=""><?php echo e(empty($warehouseForm['movementType']) ? 'Primero seleccione el
                                        tipo' : 'Seleccionar motivo'); ?></option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($reason->id); ?>"><?php echo e($reason->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['movementForm.reasonId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <!-- Observaciones -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Observaciones
                            </label>
                            <textarea wire:model.defer="movementForm.observations" rows="3"
                                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400"></textarea>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['movementForm.observations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Items Section (only if reason is selected) -->
                        <!--[if BLOCK]><![endif]--><?php if(!empty($movementForm['reasonId'])): ?>
                        <div class="border-t border-gray-200 dark:border-gray-700 pt-4">
                            <h4 class="font-medium text-gray-900 dark:text-white mb-4">Agregar productos</h4>

                            <div class="grid grid-cols-3 gap-4 mb-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Item
                                        *</label>
                                    <select wire:model.defer="detailForm.itemId"
                                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                        <option value="">Seleccionar</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['detailForm.itemId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div>
                                    <label
                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Cantidad
                                        *</label>
                                    <input type="number" step="0.01" wire:model.defer="detailForm.quantity"
                                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['detailForm.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div>
                                    <label
                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Unidad
                                        *</label>
                                    <select wire:model.defer="detailForm.unitMeasurementId"
                                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                        <option value="">Seleccionar</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->unitMeasurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->description); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['detailForm.unitMeasurementId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>

                            <button wire:click="addDetail" type="button"
                                class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white rounded-lg transition-colors">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 4v16m8-8H4"></path>
                                </svg>
                                Agregar Item
                            </button>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!-- Details Table -->
                        <!--[if BLOCK]><![endif]--><?php if(count($details) > 0): ?>
                        <div class="mt-4 overflow-x-auto">
                            <table class="w-full border border-gray-200 dark:border-gray-700 rounded-lg">
                                <thead class="bg-gray-50 dark:bg-gray-900">
                                    <tr>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Item</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Sku</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Cant Movimiento</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Unidad medida</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Unidad consumo</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Cant Actual</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Cant Ajustada</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Precio base</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Precio final</th>
                                        <th
                                            class="px-4 py-2 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Acción</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                        <td class="px-4 py-2 text-sm text-gray-900 dark:text-white"><?php echo e($detail['itemName']); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($detail['sku']); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-900 dark:text-white"><?php echo e(number_format($detail['quantity'], 0)); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($detail['unitMeasurementName']); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($detail['consumptionUnitName']); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e(number_format($detail['currentQuantity'], 0)); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e(number_format($detail['adjustedQuantity'], 0)); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400">$<?php echo e(number_format($detail['price'], 0)); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-900 dark:text-white font-semibold">$<?php echo e(number_format($detail['total'], 0)); ?></td>
                                        <td class="px-4 py-2 text-center">
                                            <button wire:click="removeDetail(<?php echo e($index); ?>)"
                                                class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300 transition-colors">
                                                <svg class="w-5 h-5 inline" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2"
                                                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                                    </path>
                                                </svg>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Actions -->
                    <div class="mt-6 flex justify-end gap-2">
                        <button wire:click="closeModal" type="button"
                            class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                            Cancelar
                        </button>
                        <button wire:click="saveMovement" type="button"
                            class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white rounded-lg transition-colors">
                            Guardar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal de Detalles del Movimiento -->
    <!--[if BLOCK]><![endif]--><?php if($showDetailsModal && !empty($movementDetails)): ?>
    <div
        class="fixed inset-0 bg-gray-600 dark:bg-gray-900 bg-opacity-50 dark:bg-opacity-75 overflow-y-auto h-full w-full z-50">
        <div class="relative min-h-screen flex items-center justify-center p-4">
            <div class="relative bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full">
                <!-- Header -->
                <div class="border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex justify-between items-center">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        Nuevo Movimiento
                        <span class="text-base font-medium text-gray-700 dark:text-gray-300">
                            | <?php echo e($this->warehouseMovement); ?>

                        </span>
                    </h3>
                    <button wire:click="closeModal"
                        class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>

                <!-- Content -->
                <div class="p-6">
                    <!-- Messages -->
                    <!--[if BLOCK]><![endif]--><?php if($successMessage): ?>
                    <div
                        class="mb-4 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                        <p class="text-sm text-green-700 dark:text-green-400"><?php echo e($successMessage); ?></p>
                    </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]--><?php if($errorMessage): ?>
                    <div
                        class="mb-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                        <p class="text-sm text-red-700 dark:text-red-400"><?php echo e($errorMessage); ?></p>
                    </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Form -->
                    <div class="space-y-4">
                        <!-- Tipo de Movimiento -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <!-- Bodegas -->
                            <!--[if BLOCK]><![endif]--><?php if($showSelectStore): ?>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Bodega
                                    <span class="text-red-500">*</span></label>
                                <select wire:model.live="selectedStoreId" <?php echo e(!empty($selectedStoreId) ? 'disabled' : ''); ?>

                                    class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 <?php echo e(!empty($selectedStoreId) ? 'opacity-75 cursor-not-allowed' : ''); ?>">
                                    <option value="">Seleccionar</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($store->id); ?>"><?php echo e($store->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedStoreId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Tipo de Movimiento <span class="text-red-500">*</span>
                                </label>
                                <div class="flex gap-4 justify-center">
                                    <label
                                        class="flex items-center <?php echo e(!empty($warehouseForm['movementType']) ? 'cursor-not-allowed' : 'cursor-pointer'); ?>">
                                        <input type="radio" wire:model.live="warehouseForm.movementType" value="ENTRADA"
                                            class="sr-only peer" <?php echo e(!empty($warehouseForm['movementType']) ? 'disabled'
                                            : ''); ?>>
                                        <div
                                            class="flex items-center px-4 py-2 border-2 rounded-lg transition-all border-gray-300 dark:border-gray-600 peer-checked:border-green-500 peer-checked:bg-green-50 dark:peer-checked:bg-green-900/20 <?php echo e(!empty($warehouseForm['movementType']) ? 'opacity-75' : ''); ?>">
                                            <svg class="w-5 h-5 mr-2 text-green-600 dark:text-green-400" fill="none"
                                                stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                            </svg>
                                            <span
                                                class="text-sm font-medium text-gray-700 dark:text-gray-300">Entradas</span>
                                        </div>
                                    </label>
                                    <label
                                        class="flex items-center <?php echo e(!empty($warehouseForm['movementType']) ? 'cursor-not-allowed' : 'cursor-pointer'); ?>">
                                        <input type="radio" wire:model.live="warehouseForm.movementType" value="SALIDA"
                                            class="sr-only peer" <?php echo e(!empty($warehouseForm['movementType']) ? 'disabled'
                                            : ''); ?>>
                                        <div
                                            class="flex items-center px-4 py-2 border-2 rounded-lg transition-all border-gray-300 dark:border-gray-600 peer-checked:border-red-500 peer-checked:bg-red-50 dark:peer-checked:bg-red-900/20 <?php echo e(!empty($warehouseForm['movementType']) ? 'opacity-75' : ''); ?>">
                                            <span
                                                class="text-sm font-medium text-gray-700 dark:text-gray-300">Salidas</span>
                                            <svg class="w-5 h-5 ml-2 text-red-600 dark:text-red-400" fill="none"
                                                stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                                            </svg>
                                        </div>
                                    </label>
                                </div>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['warehouseForm.movementType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!-- Motivo -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Motivo <span class="text-red-500">*</span>
                                </label>
                                <select wire:model.live="movementForm.reasonId" <?php if(( empty($selectedStoreId) &&
                                    $showSelectStore ) || empty($warehouseForm['movementType']) ||
                                    !empty($movementForm['reasonId'])): ?> disabled <?php endif; ?>
                                    class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                    <option value=""><?php echo e(empty($warehouseForm['movementType']) ? 'Primero seleccione el
                                        tipo' : 'Seleccionar motivo'); ?></option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($reason->id); ?>"><?php echo e($reason->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['movementForm.reasonId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <!-- Observaciones -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Observaciones
                            </label>
                            <textarea wire:model.defer="movementForm.observations" rows="3"
                                class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400"></textarea>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['movementForm.observations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Items Section (only if reason is selected) -->
                        <!--[if BLOCK]><![endif]--><?php if(!empty($movementForm['reasonId'])): ?>
                        <div class="border-t border-gray-200 dark:border-gray-700 pt-4">
                            <h4 class="font-medium text-gray-900 dark:text-white mb-4">Agregar productos</h4>

                            <div class="grid grid-cols-3 gap-4 mb-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Item
                                        *</label>
                                    <select wire:model.defer="detailForm.itemId"
                                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                        <option value="">Seleccionar</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['detailForm.itemId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div>
                                    <label
                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Cantidad
                                        *</label>
                                    <input type="number" step="0.01" wire:model.defer="detailForm.quantity"
                                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['detailForm.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div>
                                    <label
                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Unidad
                                        *</label>
                                    <select wire:model.defer="detailForm.unitMeasurementId"
                                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400">
                                        <option value="">Seleccionar</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->unitMeasurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->description); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['detailForm.unitMeasurementId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>

                            <button wire:click="addDetail" type="button"
                                class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white rounded-lg transition-colors">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 4v16m8-8H4"></path>
                                </svg>
                                Agregar Item
                            </button>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!-- Details Table -->
                        <!--[if BLOCK]><![endif]--><?php if(count($details) > 0): ?>
                        <div class="mt-4 overflow-x-auto">
                            <table class="w-full border border-gray-200 dark:border-gray-700 rounded-lg">
                                <thead class="bg-gray-50 dark:bg-gray-900">
                                    <tr>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Item</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Sku</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Cant Movimiento</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Unidad medida</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Unidad consumo</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Cant Actual</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Cant Ajustada</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Precio base</th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Precio final</th>
                                        <th
                                            class="px-4 py-2 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                                            Acción</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                        <td class="px-4 py-2 text-sm text-gray-900 dark:text-white"><?php echo e($detail['itemName']); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($detail['sku']); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-900 dark:text-white"><?php echo e(number_format($detail['quantity'], 0)); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($detail['unitMeasurementName']); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e($detail['consumptionUnitName']); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e(number_format($detail['currentQuantity'], 0)); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400"><?php echo e(number_format($detail['adjustedQuantity'], 0)); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400">$<?php echo e(number_format($detail['price'], 0)); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-900 dark:text-white font-semibold">$<?php echo e(number_format($detail['total'], 0)); ?></td>
                                        <td class="px-4 py-2 text-center">
                                            <button wire:click="removeDetail(<?php echo e($index); ?>)"
                                                class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300 transition-colors">
                                                <svg class="w-5 h-5 inline" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2"
                                                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                                    </path>
                                                </svg>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Actions -->
                    <div class="mt-6 flex justify-end gap-2">
                        <button wire:click="closeModal" type="button"
                            class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                            Cancelar
                        </button>
                        <button wire:click="saveMovement" type="button"
                            class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white rounded-lg transition-colors">
                            Guardar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--[if BLOCK]><![endif]--><?php if($showDetailsModal && !empty($movementDetails)): ?>
    <div class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <!-- Header -->
            <div
                class="sticky top-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    Detalles del Movimiento #<?php echo e($movementDetails['consecutive']); ?>

                </h3>
                <button wire:click="closeDetailsModal"
                    class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12">
                        </path>
                    </svg>
                </button>
            </div>

            <!-- Información del Movimiento -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Fecha</p>
                        <p class="text-sm font-medium text-gray-900 dark:text-white">
                            <?php echo e($movementDetails['date']); ?>

                        </p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Tipo</p>
                        <p class="text-sm font-medium text-gray-900 dark:text-white">
                            <?php echo e($movementDetails['type']); ?>

                        </p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Bodega</p>
                        <p class="text-sm font-medium text-gray-900 dark:text-white">
                            <?php echo e($movementDetails['store_name']); ?>

                        </p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Usuario</p>
                        <p class="text-sm font-medium text-gray-900 dark:text-white">
                            <?php echo e($movementDetails['user_name']); ?>

                        </p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Razón</p>
                        <p class="text-sm font-medium text-gray-900 dark:text-white">
                            <?php echo e($movementDetails['reason_name']); ?>

                        </p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Estado</p>
                        <!--[if BLOCK]><![endif]--><?php if($movementDetails['status'] === 1): ?>
                        <span
                            class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                            Registrado
                        </span>
                        <?php else: ?>
                        <span
                            class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                            Anulado
                        </span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="mt-4">
                    <p class="text-sm text-gray-500 dark:text-gray-400">Observaciones</p>
                    <p class="text-sm font-medium text-gray-900 dark:text-white">
                        <?php echo e($movementDetails['observations'] ? $movementDetails['observations'] : 'Sin observaciones'); ?>

                    </p>
                </div>
            </div>

            <!-- Tabla de Items -->
            <div class="px-6 py-4">
                <h4 class="text-sm font-semibold text-gray-900 dark:text-white mb-3">Items del Movimiento</h4>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th
                                    class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                                    Producto</th>
                                <th
                                    class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                                    Cantidad</th>
                                <th
                                    class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">
                                    Unidad</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $movementDetails['details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                <td class="px-4 py-2 text-sm text-gray-900 dark:text-white">
                                    <?php echo e($detail['item_name']); ?>

                                </td>
                                <td class="px-4 py-2 text-sm text-gray-900 dark:text-white">
                                    <?php echo e($detail['quantity']); ?>

                                </td>
                                <td class="px-4 py-2 text-sm text-gray-900 dark:text-white">
                                    <?php echo e($detail['unit_name']); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="px-4 py-4 text-center text-sm text-gray-500 dark:text-gray-400">
                                    No hay items en este movimiento
                                </td>
                            </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Footer -->
            <div class="bg-gray-50 dark:bg-gray-700 px-6 py-4 flex justify-between items-center">
                <div>
                    <!--[if BLOCK]><![endif]--><?php if($movementDetails['status'] === 1): ?>
                        <button @click="$dispatch('confirm-annul-from-details', { movementId: <?php echo e($movementDetails['id']); ?>, consecutive: '<?php echo e($movementDetails['consecutive']); ?>' })"
                            class="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600 text-white rounded-lg transition-colors text-sm font-medium focus:outline-none focus:ring-2 focus:ring-red-500">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                            Anular Movimiento
                        </button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <button wire:click="closeDetailsModal"
                    class="px-4 py-2 bg-gray-200 dark:bg-gray-600 text-gray-900 dark:text-white rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors text-sm font-medium">
                    Cerrar
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->  
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

  <!-- Modal de Confirmación para Anular (Global) -->
  <div x-data="{ 
      showConfirm: false, 
      movementId: null, 
      consecutive: '' 
  }"
      @confirm-annul-from-details.window="showConfirm = true; movementId = $event.detail.movementId; consecutive = $event.detail.consecutive"
      x-show="showConfirm"
      x-cloak
      class="fixed inset-0 z-[60] overflow-y-auto"
      style="display: none;">
      
      <!-- Overlay -->
      <div class="fixed inset-0 bg-black bg-opacity-50 transition-opacity" @click="showConfirm = false"></div>
      
      <!-- Modal -->
      <div class="flex items-center justify-center min-h-screen p-4">
          <div @click.away="showConfirm = false"
              x-transition:enter="transition ease-out duration-300"
              x-transition:enter-start="opacity-0 transform scale-90"
              x-transition:enter-end="opacity-100 transform scale-100"
              x-transition:leave="transition ease-in duration-200"
              x-transition:leave-start="opacity-100 transform scale-100"
              x-transition:leave-end="opacity-0 transform scale-90"
              class="relative bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full p-6">
              
              <!-- Icon -->
              <div class="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-red-100 dark:bg-red-900/20 rounded-full">
                  <svg class="w-6 h-6 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                  </svg>
              </div>
              
              <!-- Content -->
              <div class="text-center">
                  <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      Anular Movimiento
                  </h3>
                  <p class="text-sm text-gray-600 dark:text-gray-400 mb-1">
                      ¿Está seguro de que desea anular el movimiento 
                      <span class="font-semibold text-gray-900 dark:text-white" x-text="'#' + consecutive"></span>?
                  </p>
                  <p class="text-sm text-red-600 dark:text-red-400 font-medium">
                      Esta acción no se puede deshacer.
                  </p>
              </div>
              
              <!-- Actions -->
              <div class="flex gap-3 mt-6">
                  <button @click="showConfirm = false"
                      class="flex-1 px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors">
                      Cancelar
                  </button>
                  <button @click="$wire.annulMovement(movementId); showConfirm = false"
                      class="flex-1 px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors">
                      Sí, Anular
                  </button>
              </div>
          </div>
      </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\01DISTRIBUCIONES\resources\views/livewire/tenant/movements/components/movement-form.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos Cargue #<?php echo e($deliveryId); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            font-size: 10px;
            line-height: 1.3;
            color: #000;
            background: #fff;
        }

        /* Container para cada fila de 2 pedidos */
        .row {
            width: 100%;
            display: flex;
            flex-wrap: wrap;
        }

        .row::after {
            content: "";
            clear: both;
            display: table;
        }
        
        /* Tarjeta de pedido - 2 por fila (50% cada una) */
        .pedido {
            width: 50%;
            float: left;
            padding: 5px;
            box-sizing: border-box;
        }

        .pedido-inner {
            border: 1px solid #000;
            padding: 8px;
            height: 100%;
            min-height: 9.5cm;
            position: relative;
        }
        
        /* === ENCABEZADO === */
        .cliente table {
            width: 100%;
            border-collapse: collapse;
        }

        .cliente td {
            vertical-align: top;
            padding: 2px;
        }

        .cliente .izq {
            width: 60px;
        }

        .cliente .centro {
            text-align: center;
        }

        .cliente .derecha {
            text-align: right;
            width: 150px;
        }

        .logo {
            max-width: 50px;
            max-height: 40px;
        }

        h3 {
            font-size: 11px;
            margin: 0;
            padding: 2px;
        }

        /* === SECCIÓN CLIENTE/VENDEDOR === */
        .cliente p {
            font-size: 10px;
            margin: 1px 0;
        }

        /* === TABLA DETALLES === */
        .det {
            margin-top: 5px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 9px;
        }

        .table thead tr {
            border-bottom: 1px solid #000;
        }

        .table th {
            font-size: 9px;
            padding: 3px;
            text-align: left;
            font-weight: bold;
        }

        .table td {
            font-size: 9px;
            padding: 2px 3px;
            border-bottom: 1px solid #eee;
            white-space: nowrap;
        }

        .table td:nth-child(4),
        .table td:nth-child(5),
        .table th:nth-child(4),
        .table th:nth-child(5) {
            text-align: right;
        }

        .table td:nth-child(2),
        .table th:nth-child(2) {
            text-align: center;
        }

        /* === TOTALES === */
        .totales {
            margin-top: 5px;
            font-size: 9px;
            position: relative;
            min-height: 80px;
        }

        .solos {
            font-size: 8px;
            font-style: italic;
            margin-bottom: 5px;
        }

        .solos p {
            margin: 2px 0;
        }

        .izq1 {
            float: left;
            width: 55%;
        }

        .izq1 p {
            font-weight: bold;
            font-size: 9px;
            text-transform: uppercase;
        }

        .valores1 {
            float: left;
            width: 25%;
            text-align: right;
        }

        .valores1 p {
            font-size: 9px;
            margin: 1px 0;
        }

        .valores2 {
            float: right;
            width: 20%;
            text-align: right;
        }

        .valores2 p {
            font-size: 9px;
            margin: 1px 0;
        }

        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        /* === PIE DE PÁGINA === */
        .pie {
            clear: both;
            text-align: center;
            padding-top: 10px;
            margin-top: 10px;
        }

        .pie p {
            color: #c00;
            font-size: 10px;
            font-weight: bold;
        }

        /* === IMPRESIÓN === */
        @media print {
            @page {
                size: letter landscape;
                margin: 0.3cm;
            }
            
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .pedido {
                width: 50%;
                float: left;
                page-break-inside: avoid;
            }
            
            .page-break {
                page-break-after: always;
                clear: both;
            }

            .row {
                page-break-inside: avoid;
            }
        }
        
        /* Vista previa en pantalla */
        @media screen {
            body {
                background: #888;
                padding: 10px;
            }
            
            .pagina-container {
                background: #fff;
                max-width: 28cm;
                margin: 0 auto 20px auto;
                padding: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            }
        }
    </style>
</head>
<body>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($customerOrders) > 0): ?>
        <?php
            // Agrupar pedidos en grupos de 4 (2 filas x 2 columnas por página)
            $orderChunks = collect($customerOrders)->chunk(4);
            $globalIndex = 0;
        ?>
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $orderChunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageIndex => $pageOrders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="pagina-container">
                <div class="row">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pageOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $globalIndex++;
                            $orderNumber = $order['order_number'] ?? (101815 + $globalIndex - 1);
                            $totalPages = $order['total_pages'] ?? 1;
                            $currentPage = $order['current_page'] ?? 1;
                        ?>
                        <div class="pedido">
                            <div class="pedido-inner">
                                <!-- ENCABEZADO -->
                                <section class="cliente">
                                    <table>
                                        <tr>
                                            <td class="izq">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($empresa) && isset($empresa['logo'])): ?>
                                                    <img src="<?php echo e($empresa['logo']); ?>" class="logo">
                                                <?php else: ?>
                                                    <img src="/files/logos/logo.png" class="logo" onerror="this.style.display='none'">
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                            <td class="centro">
                                                <h3><?php echo e($empresa['nombre'] ?? 'Mas distribuciones JM'); ?></h3>
                                                <p>Nit: <?php echo e($empresa['documento'] ?? '1017134785-1'); ?></p>
                                                <p><strong>PÁGINA: <?php echo e($currentPage); ?> de <?php echo e($totalPages); ?></strong></p>
                                            </td>
                                            <td class="derecha">
                                                <p><strong>PEDIDO # <?php echo e($orderNumber); ?></strong></p>
                                                <p><strong>FECHA: <?php echo e(\Carbon\Carbon::parse($order['order_date'] ?? now())->format('Y-m-d')); ?></strong></p>
                                                <p><strong>FECHA ENTRE: <?php echo e(\Carbon\Carbon::parse($order['delivery_date'] ?? now()->addDays(3))->format('Y-m-d')); ?></strong></p>
                                            </td>
                                        </tr>
                                    </table>
                                </section>

                                <!-- DATOS CLIENTE Y VENDEDOR -->
                                <section class="cliente">
                                    <table>
                                        <tr>
                                            <td>
                                                <p>Cliente: <?php echo e($order['customer']['name']); ?></p>
                                                <p>Identificación: <?php echo e($order['customer']['identification']); ?></p>
                                                <p>Barrio: <?php echo e($order['customer']['district']); ?></p>
                                            </td>
                                            <td>
                                                <p>Contacto: <?php echo e($order['customer']['contact_name'] ?? ''); ?></p>
                                                <p>Dirección: <?php echo e($order['customer']['address']); ?></p>
                                                <p>Teléfono: <?php echo e($order['customer']['phone']); ?></p>
                                            </td>
                                            <td>
                                                <p>Vendedor: <?php echo e($order['customer']['salesPerson'] ?? 'JULIO RIAÑO'); ?></p>
                                                <p>Día visita: <?php echo e($order['customer']['saleDay'] ?? ''); ?></p>
                                                <p>Tel vendedor: <?php echo e($order['customer']['telvendedor'] ?? '304 6800740'); ?></p>
                                            </td>
                                        </tr>
                                    </table>
                                    <p>Observaciones: <?php echo e($order['observations'] ?? ''); ?></p>
                                </section>

                                <!-- DETALLES / ITEMS -->
                                <section class="det">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Ref</th>
                                                <th>Cant</th>
                                                <th>Descripcion</th>
                                                <th>Precio</th>
                                                <th>Subtotal</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $order['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item['code']); ?></td>
                                                <td style="text-align: center;"><?php echo e(number_format($item['quantity'], 0)); ?></td>
                                                <td><?php echo e($item['name']); ?></td>
                                                <td><?php echo e(number_format($item['unit_price'] ?? ($item['subtotal'] / max($item['quantity'], 1)), 0, ',', '.')); ?></td>
                                                <td><?php echo e(number_format($item['subtotal'], 0, ',', '.')); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </tbody>
                                    </table>
                                </section>

                                <!-- TOTALES -->
                                <section class="totales clearfix">
                                    <div class="solos">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($order['description']) && $order['description']): ?>
                                            <p>Descripcion: <?php echo e($order['description']); ?></p>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <p>Documento sustitutivo de la factura, Decreto 1514 del 98 articulo 1, IVA Regimen simplificado</p>
                                    </div>
                                    <div class="izq1">
                                        <p>VALOR EN LETRAS: <?php echo e($order['totalInWords'] ?? ''); ?></p>
                                    </div>
                                    <div class="valores1">
                                        <p>TOTAL PAGINA</p>
                                        <p>Subtotal Pedido</p>
                                        <p>Iva</p>
                                        <p><strong>TOTAL A PAGAR</strong></p>
                                    </div>
                                    <div class="valores2">
                                        <p>$ <?php echo e(number_format($order['page_total'] ?? $order['total'], 0, ',', '.')); ?></p>
                                        <p>$ <?php echo e(number_format($order['subtotal'] ?? $order['total'], 0, ',', '.')); ?></p>
                                        <p>$0</p>
                                        <p><strong>$ <?php echo e(number_format($order['total'], 0, ',', '.')); ?></strong></p>
                                    </div>
                                </section>

                                <!-- PIE DE PÁGINA -->
                                <section class="pie">
                                    <p>Telefono: <?php echo e($empresa['telefono'] ?? '6014774491'); ?> - Bogota - Colombia</p>
                                </section>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$loop->last): ?>
                <div class="page-break"></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php else: ?>
        <div style="text-align: center; padding: 50px; font-size: 14px;">
            No se encontraron pedidos para esta entrega.
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\01DISTRIBUCIONES\resources\views/tenant/uploads/print-orders-detail.blade.php ENDPATH**/ ?>
<svg class="w-8 h-8 sm:w-10 sm:h-10 stroke-[3]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M5 12h14"/>
</svg><?php /**PATH C:\xampp\htdocs\01DISTRIBUCIONES\storage\framework\views/be8e558780dd167f3c332c2de40c477a.blade.php ENDPATH**/ ?>
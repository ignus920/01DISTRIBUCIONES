<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Tipo</th>
            <th>Motivo</th>
            <th>Medio de Pago</th>
            <th>Valor</th>
            <th>Observaciones</th>
            <th>Fecha</th>
        </tr>
    </thead>
    <tbody>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($detail->id); ?></td>
            <td><?php echo e($detail->reasonsPettyCash->type == 'i' ? 'Ingreso' : 'Egreso'); ?></td>
            <td><?php echo e($detail->reasonsPettyCash->name); ?></td>
            <td><?php echo e($detail->methodPayments->name); ?></td>
            <td><?php echo e($detail->methodPayments->value); ?></td>
            <td><?php echo e($detail->observations); ?></td>
            <td><?php echo e($detail->created_at->format('Y-m-d H:i:s')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\01DISTRIBUCIONES\resources\views/livewire/tenant/petty-cash/petty-cash-excel.blade.php ENDPATH**/ ?>
<div class="p-4 sm:p-6 dark:bg-slate-900 min-h-screen">
    <div class="max-w-7xl mx-auto">
        
        <!-- Header & Instructions -->
        <div class="mb-8">
            <h1 class="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-2">
                Recepción de Pedidos <?php echo e($order_number ? "- Orden #$order_number" : ''); ?>

            </h1>
            <p class="text-gray-600 dark:text-slate-400">
                Verifica y ajusta las cantidades recibidas antes de confirmar el ingreso al inventario.
            </p>
        </div>

        <!-- Toolbar / Search -->
        <div class="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
            <div class="w-full sm:w-1/2 relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg class="h-5 w-5 text-gray-400" fill="none" class="w-6 h-6" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </div>
                <input 
                    type="text" 
                    wire:model.live.debounce.300ms="search"
                    class="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-slate-700 rounded-lg leading-5 bg-white dark:bg-slate-800 dark:text-gray-300 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm shadow-sm transition duration-150 ease-in-out" 
                    placeholder="Buscar por nombre, SKU o número de orden..."
                >
            </div>
            
            <div class="flex items-center gap-2">
                 <!-- Stats or Filters could go here -->
                 <span class="text-sm font-medium text-gray-500 dark:text-slate-400 bg-gray-100 dark:bg-slate-800 px-3 py-1 rounded-full">
                    <?php echo e(count($items)); ?> Ítems Pendientes
                 </span>
            </div>
        </div>

        <!-- Main Table Card -->
        <div class="bg-white dark:bg-slate-800 shadow rounded-lg overflow-hidden border border-gray-200 dark:border-slate-700">
            
            <!--[if BLOCK]><![endif]--><?php if(count($items) > 0): ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-slate-700">
                        <thead class="bg-gray-50 dark:bg-slate-700/50">
                            <tr class="border-b border-gray-200 dark:border-slate-700">
                                <th scope="col" class="px-6 py-3 text-center">
                                    <!--[if BLOCK]><![endif]--><?php if($items->where('status', '!==', 'Recibido')->count() > 0): ?>
                                        <input type="checkbox" wire:model.live="selectAll" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                    <?php else: ?>
                                        <span class="text-xs text-gray-500 font-medium">#</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-slate-300 uppercase tracking-wider">
                                    Producto
                                </th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-slate-300 uppercase tracking-wider">
                                    Referencia
                                </th>
                                <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                                    Solicitado
                                </th>
                                <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-indigo-600 dark:text-indigo-400 uppercase tracking-wider w-32">
                                    Recibido
                                </th>
                                <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-slate-300 uppercase tracking-wider">
                                    Diferencia
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white dark:bg-slate-800 divide-y divide-gray-200 dark:divide-slate-700">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $req = $item->quantity_request;
                                    $rec = $quantities[$item->id] ?? $req; // Default to request if not set (though logic sets it)
                                    $recInt = intval($rec);
                                    $diff = $recInt - $req;
                                ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors <?php echo e($item->status === 'Recibido' ? 'bg-gray-50 dark:bg-slate-800/80' : ''); ?>">
                                    <td class="px-6 py-4 whitespace-nowrap text-center">
                                        <!--[if BLOCK]><![endif]--><?php if($item->status !== 'Recibido'): ?>
                                             <input 
                                                 type="checkbox" 
                                                 value="<?php echo e($item->id); ?>" 
                                                 wire:model.live="selected" 
                                                 class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 disabled:opacity-50 disabled:bg-gray-200 dark:disabled:bg-slate-700 disabled:cursor-not-allowed"
                                                 <?php if(intval($quantities[$item->id] ?? 0) <= 0): ?> disabled <?php endif; ?>
                                             >
                                        <?php else: ?>
                                            <span class="text-green-500">
                                                <svg class="w-5 h-5 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="ml-0">
                                                <div class="text-sm font-bold text-gray-900 dark:text-white uppercase">
                                                    <?php echo e($item->item_name); ?>

                                                </div>
                                                <div class="text-xs text-gray-500 dark:text-slate-400 font-mono">
                                                    <?php echo e($item->sku); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900 dark:text-gray-200">
                                            <?php echo e($item->remise_number ?: 'Sin Remisión'); ?>

                                        </div>
                                        <div class="text-xs text-gray-500 dark:text-slate-400">
                                            Ord: #<?php echo e($item->order_number); ?>

                                        </div>
                                        <div class="text-xs text-gray-400 dark:text-slate-500 mt-0.5">
                                            <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d/m/Y')); ?>

                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-center">
                                         <span class="inline-flex items-center justify-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300 min-w-[3rem]">
                                            <?php echo e(number_format($req, 0)); ?>

                                         </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-center">
                                        <!-- Input for Quantity -->
                                        <input 
                                            type="number" 
                                            wire:model.blur="quantities.<?php echo e($item->id); ?>"
                                            class="w-20 sm:w-24 text-center border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm bg-white dark:bg-slate-900 dark:text-white font-bold disabled:opacity-60 disabled:bg-gray-100 dark:disabled:bg-slate-800"
                                            min="0"
                                            <?php if($item->status === 'Recibido'): ?> disabled <?php endif; ?>
                                        >
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-center">
                                        <!--[if BLOCK]><![endif]--><?php if($diff == 0): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                                                Exacto
                                            </span>
                                        <?php elseif($diff > 0): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300">
                                                +<?php echo e($diff); ?> (Exceso)
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300">
                                                <?php echo e($diff); ?> (Faltante)
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <!-- Empty State -->
                <div class="text-center py-12 px-4">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">No hay pedidos pendientes</h3>
                    <p class="mt-1 text-sm text-gray-500 dark:text-slate-400">Todo está al día. ¡Buen trabajo!</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            
            <!-- Footer with Actions -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-slate-700/50 border-t border-gray-200 dark:border-slate-700 flex justify-between items-center gap-4">
                <a href="<?php echo e(route('tenant.tat.restock.list')); ?>" class="text-sm font-medium text-gray-700 dark:text-slate-300 hover:text-gray-500 dark:hover:text-slate-200">
                    <?php echo e(count($items) > 0 ? 'Cancelar y Volver' : 'Volver a la lista'); ?>

                </a>

                    <!--[if BLOCK]><![endif]--><?php if(count($selected) > 0): ?>
                    <div class="flex items-center gap-4 animate-fade-in">
                        <span class="text-sm font-medium text-gray-600 dark:text-slate-400">
                            <?php echo e(count($selected)); ?> items seleccionados
                        </span>
                            <button
                            wire:click="confirmSelected"
                            wire:confirm="¿Confirmar <?php echo e(count($selected)); ?> items seleccionados?"
                            class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors"
                        >
                            Confirmar Seleccionados
                        </button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>

    <!-- Toast Scripts if needed (though usually in layout) -->
    <script>
        document.addEventListener('livewire:initialized', () => {
             Livewire.on('show-toast', (data) => {
                const payload = Array.isArray(data) ? data[0] : data;
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                });
                Toast.fire({
                    icon: payload.type || 'info',
                    title: payload.message
                });
            });
            
             Livewire.on('item-marked-received', () => {
                 // Refresh handled by Livewire re-render
                 // Optional sound or confetti
            });
        });
    </script>
</div>


<?php /**PATH C:\xampp\htdocs\01DISTRIBUCIONES\resources\views/livewire/TAT/orders/receive-orders.blade.php ENDPATH**/ ?>
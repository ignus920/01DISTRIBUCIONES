<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['paginator']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['paginator']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!--[if BLOCK]><![endif]--><?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination Navigation" class="flex items-center justify-between">
        <!-- Información de página -->
        <div class="text-sm text-gray-700 dark:text-gray-300">
            <span class="hidden sm:inline">
                Mostrando <span class="font-medium"><?php echo e($paginator->firstItem()); ?></span>
                a <span class="font-medium"><?php echo e($paginator->lastItem()); ?></span>
                de <span class="font-medium"><?php echo e($paginator->total()); ?></span> resultados
            </span>
            <span class="sm:hidden">
                Página <span class="font-medium"><?php echo e($paginator->currentPage()); ?></span>
                de <span class="font-medium"><?php echo e($paginator->lastPage()); ?></span>
            </span>
        </div>

        <!-- Botones de paginación -->
        <div class="flex items-center gap-1 sm:gap-2">
            
            <!--[if BLOCK]><![endif]--><?php if($paginator->onFirstPage()): ?>
                <span class="px-2 sm:px-3 py-2 text-sm font-medium text-gray-400 dark:text-gray-600 bg-gray-100 dark:bg-gray-700 rounded-lg cursor-not-allowed">
                    <span class="hidden sm:inline">← Anterior</span>
                    <span class="sm:hidden">←</span>
                </span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"
                    class="px-2 sm:px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
                    <span class="hidden sm:inline">← Anterior</span>
                    <span class="sm:hidden">←</span>
                </a>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <div class="hidden md:flex items-center gap-1">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $paginator->getUrlRange(1, $paginator->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--[if BLOCK]><![endif]--><?php if($page == $paginator->currentPage()): ?>
                        <span class="px-3 py-2 text-sm font-medium text-white bg-indigo-600 dark:bg-indigo-500 rounded-lg">
                            <?php echo e($page); ?>

                        </span>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>"
                            class="px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
                            <?php echo e($page); ?>

                        </a>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            
            <div class="md:hidden flex items-center gap-1">
                <span class="px-3 py-2 text-sm font-medium text-white bg-indigo-600 dark:bg-indigo-500 rounded-lg">
                    <?php echo e($paginator->currentPage()); ?>

                </span>
            </div>

            
            <!--[if BLOCK]><![endif]--><?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"
                    class="px-2 sm:px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
                    <span class="hidden sm:inline">Siguiente →</span>
                    <span class="sm:hidden">→</span>
                </a>
            <?php else: ?>
                <span class="px-2 sm:px-3 py-2 text-sm font-medium text-gray-400 dark:text-gray-600 bg-gray-100 dark:bg-gray-700 rounded-lg cursor-not-allowed">
                    <span class="hidden sm:inline">Siguiente →</span>
                    <span class="sm:hidden">→</span>
                </span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </nav>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH C:\xampp\htdocs\01DISTRIBUCIONES\resources\views/components/responsive-pagination.blade.php ENDPATH**/ ?>
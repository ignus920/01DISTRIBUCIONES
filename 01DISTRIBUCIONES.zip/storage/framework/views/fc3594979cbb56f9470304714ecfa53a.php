<div>
    <!--[if BLOCK]><![endif]--><?php if($showLabel): ?>
        <label for="type_identification_<?php echo e($name); ?>" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
            <?php echo e($label); ?>

            <!--[if BLOCK]><![endif]--><?php if($required): ?> <span class="text-red-500">*</span> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </label>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <select
        wire:model.live="typeIdentificationId"
        name="<?php echo e($name); ?>"
        id="type_identification_<?php echo e($name); ?>"
        <?php if($required): ?> required <?php endif; ?>
        class="<?php echo e($class); ?> bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 border-gray-300 dark:border-gray-600"
        wire:loading.attr="disabled">
        <option value=""><?php echo e($placeholder); ?></option>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $typeIdentifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeIdentification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($typeIdentification->id); ?>">
                <?php echo e($typeIdentification->name); ?> (<?php echo e($typeIdentification->acronym); ?>)
            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </select>

    <!--[if BLOCK]><![endif]--><?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-red-500 dark:text-red-400 text-sm"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\01DISTRIBUCIONES\resources\views/livewire/selects/type-identification-select.blade.php ENDPATH**/ ?>
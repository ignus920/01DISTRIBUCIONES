
<script>
    // Prevenir múltiples configuraciones de listeners
    if (typeof window.remissionPrintListenerConfigured === 'undefined') {
        window.remissionPrintListenerConfigured = true;

        // Función de impresión inline para producción
        function openPrintWindow(eventData) {
            console.log('🖨️ openPrintWindow ejecutada (inline):', eventData);

            const data = Array.isArray(eventData) ? eventData[0] : eventData;
            const url = data.url;
            const format = data.format;

            console.log('🔗 URL a imprimir:', url, '📄 Formato:', format);

            // Tamaño de ventana según formato
            const features = format === 'pos' ?
                'width=400,height=600,scrollbars=yes,resizable=yes,menubar=no,toolbar=no' :
                'width=800,height=900,scrollbars=yes,resizable=yes,menubar=no,toolbar=no';

            // Abrir ventana
            const win = window.open(url, 'printWindow_' + Date.now(), features);

            if (!win) {
                alert('⚠️ No se pudo abrir la ventana. Verifica que las ventanas emergentes estén permitidas.');
                return;
            }

            console.log('✅ Ventana abierta correctamente');
            win.focus();

            // Auto impresión cuando la página cargue
            win.onload = function() {
                setTimeout(() => {
                    console.log('🖨️ Iniciando impresión automática...');
                    win.print();
                }, 800);
            };
        }

        // Función para configurar listener una sola vez
        function configurePrintListener() {
            if (window.Livewire && !window.remissionPrintListenerRegistered) {
                window.remissionPrintListenerRegistered = true;
                Livewire.on('open-print-window', openPrintWindow);
                console.log('✅ Listener Livewire configurado una sola vez');
            }
        }

        // Configurar listeners cuando el documento esté listo
        document.addEventListener('DOMContentLoaded', function() {
            console.log('🔧 Configurando listeners de impresión inline...');
            configurePrintListener();
        });

        // También configurar cuando Livewire se inicialice
        document.addEventListener('livewire:initialized', function() {
            console.log('🔧 Livewire inicializado, verificando configuración...');
            configurePrintListener();
        });

        // Para Livewire 3 también
        document.addEventListener('livewire:navigated', function() {
            console.log('🔧 Livewire navegado, verificando configuración...');
            configurePrintListener();
        });

        console.log('🛡️ Sistema de impresión protegido contra duplicados');
    }
</script>
<?php /**PATH C:\xampp\htdocs\01DISTRIBUCIONES\resources\views/livewire/tenant/remissions/print-script.blade.php ENDPATH**/ ?>
<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
            <?php echo e(__('Profile Photo')); ?>

        </h2>

        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            <?php echo e(__("Actualiza la foto de perfil de tu cuenta.")); ?>

        </p>
    </header>

    <!-- Mensaje de éxito -->
    <!--[if BLOCK]><![endif]--><?php if(session('avatar-message')): ?>
        <div class="mt-4 p-4 bg-green-100 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-800 dark:text-green-200 rounded-lg">
            <?php echo e(session('avatar-message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div class="mt-6 space-y-6">
        <!-- Avatar actual -->
        <div class="flex items-center space-x-6">
            <div class="shrink-0">
                <img class="h-16 w-16 rounded-full object-cover border-2 border-gray-300 dark:border-gray-600"
                     src="<?php echo e(auth()->user()->getAvatarUrl()); ?>"
                     alt="Avatar actual"
                     id="current-avatar">
            </div>

            <div class="flex-1">
                <div class="flex items-center space-x-2">
                    <!--[if BLOCK]><![endif]--><?php if(auth()->user()->hasCustomAvatar()): ?>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-200">
                            Foto personalizada
                        </span>
                    <?php else: ?>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                            Usando iniciales
                        </span>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    JPG, PNG máximo 2MB
                </p>
            </div>
        </div>

        <!-- Preview de nueva imagen -->
        <!--[if BLOCK]><![endif]--><?php if($avatar): ?>
            <div class="flex items-center space-x-6">
                <div class="shrink-0">
                    <img class="h-16 w-16 rounded-full object-cover border-2 border-indigo-300 dark:border-indigo-600"
                         src="<?php echo e($avatar->temporaryUrl()); ?>"
                         alt="Vista previa">
                </div>
                <div class="flex-1">
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 dark:bg-indigo-900/20 text-indigo-800 dark:text-indigo-200">
                        Vista previa
                    </span>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        Esta será tu nueva foto de perfil
                    </p>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Formulario de subida -->
        <form wire:submit="save" class="space-y-4">
            <div>
                <label for="avatar" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Seleccionar nueva foto
                </label>
                <input
                    type="file"
                    wire:model="avatar"
                    id="avatar"
                    accept="image/*"
                    class="block w-full text-sm text-gray-500 dark:text-gray-400
                           file:mr-4 file:py-2 file:px-4
                           file:rounded-md file:border-0
                           file:text-sm file:font-medium
                           file:bg-indigo-50 file:text-indigo-700
                           dark:file:bg-indigo-900/20 dark:file:text-indigo-400
                           hover:file:bg-indigo-100 dark:hover:file:bg-indigo-900/30
                           file:transition-colors file:cursor-pointer
                           border border-gray-300 dark:border-gray-600 rounded-md
                           bg-white dark:bg-gray-700"
                >
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 dark:text-red-400 text-sm mt-1"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Indicador de carga mejorado -->
            <div wire:loading wire:target="avatar" class="mt-3 p-3 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800 rounded-lg">
                <div class="flex items-center space-x-3">
                    <svg class="animate-spin h-5 w-5 text-indigo-600 dark:text-indigo-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span class="text-sm font-medium text-indigo-800 dark:text-indigo-200">Subiendo imagen...</span>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="flex items-center gap-4">
                <!--[if BLOCK]><![endif]--><?php if($avatar): ?>
                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:loading.attr' => 'disabled','wire:target' => 'save']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:target' => 'save']); ?>
                        <?php echo e(__('Save Photo')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>

                    <button type="button" wire:click="$set('avatar', null)" class="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition-colors">
                        Cancelar
                    </button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!--[if BLOCK]><![endif]--><?php if(auth()->user()->hasCustomAvatar()): ?>
                    <button type="button"
                            wire:click="deleteAvatar"
                            wire:confirm="¿Estás seguro de que quieres eliminar tu foto de perfil?"
                            class="text-sm text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-200 transition-colors">
                        Eliminar foto actual
                    </button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </form>
    </div>

</section>
<?php /**PATH C:\xampp\htdocs\01DISTRIBUCIONES\resources\views/livewire/profile/update-avatar-form.blade.php ENDPATH**/ ?>
@extends('layouts.app')

@section('content')
<livewire:tenant.vnt-customer.vnt-customer-index />
@endsection
import './bootstrap';
import './print-listeners';

// import Swal from 'sweetalert2';
// window.Swal = Swal;
